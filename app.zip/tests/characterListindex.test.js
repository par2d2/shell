import React from 'react';
import CharacterList from "../components/characterList/characterList";

it('should render a table with data', ()=>{
    render( <CharacterList />)
})