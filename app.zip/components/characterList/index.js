import CharacterList from './CharacterList.js';
export default CharacterList;
