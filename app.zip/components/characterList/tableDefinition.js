export const tableDefinition = {
    0:{
        id: "name",
        label: "Name"
    },
    1:{
        id: "height",
        label: "Height"
    },
    2:{
        id: "hair_color",
        label: "Hair Colour"
    },
    3:{
        id: "eye_color",
        label: "Eye Color"
    },
    4:{
        id: "skin_color",
        label: "Skin Colour"
    },
    5:{
        id: "birth_year",
        label: "Birth Year"
    },
    6:{
        id: "gender",
        label: "Gender"
    },
}